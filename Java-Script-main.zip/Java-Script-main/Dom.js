type="text/javascript">
			function alertFun(){
				alert('Hello');
			}