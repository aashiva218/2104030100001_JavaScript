var a=143;
var b=143;
var c=a+b;

document.write("sum value:-,c");